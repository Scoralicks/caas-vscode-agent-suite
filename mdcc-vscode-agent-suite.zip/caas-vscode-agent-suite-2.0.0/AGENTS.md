# Repository agent guidance

For any task concerning Microsoft Dynamics 365 Contact Center, use the agents in `.github/agents` and the common policy in `.github/instructions/mdcc-common.instructions.md`.

The official documentation must be synchronized with `scripts/sync-mdcc-docs.ps1` or the VS Code task **MDCC: Sync official documentation** before relying on local source files.

Do not answer product questions from model memory when official documentation is available.

Use `Technical Researcher` and the workspace `agent-reach` skill for broader technical research, content production, ecosystem signals, and prototypes. Community sources are supplementary and must never override official Microsoft documentation for MDCC product claims.
