$ErrorActionPreference = 'Stop'
$workspaceRoot = Split-Path -Parent $PSScriptRoot

$requiredFiles = @(
    '.github/agents/technical-researcher.agent.md',
    '.github/skills/agent-reach/SKILL.md',
    'config/agent-reach.json',
    'docs/agent-reach.md',
    'scripts/setup-agent-reach.ps1',
    'scripts/setup-agent-reach.sh',
    'scripts/agent-reach-doctor.ps1',
    'scripts/agent-reach-doctor.sh',
    'vendor/agent-reach/Agent-Reach-main.zip',
    'vendor/agent-reach/LICENSE'
)
foreach ($relativePath in $requiredFiles) {
    $path = Join-Path $workspaceRoot $relativePath
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Required integration file is missing: $relativePath"
    }
}

$config = Get-Content -Raw -LiteralPath (Join-Path $workspaceRoot 'config/agent-reach.json') | ConvertFrom-Json
$sourceZip = Join-Path $workspaceRoot $config.upstream.source
$actualHash = (Get-FileHash -LiteralPath $sourceZip -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actualHash -ne $config.upstream.sha256) {
    throw "Vendored source checksum mismatch: $actualHash"
}

$tasks = Get-Content -Raw -LiteralPath (Join-Path $workspaceRoot '.vscode/tasks.json') | ConvertFrom-Json
$labels = @($tasks.tasks | ForEach-Object label)
foreach ($label in @('Research: Install Agent Reach (safe)', 'Research: Agent Reach doctor')) {
    if ($label -notin $labels) { throw "VS Code task is missing: $label" }
}

$master = Get-Content -Raw -LiteralPath (Join-Path $workspaceRoot '.github/agents/mdcc-master.agent.md')
if ($master -notmatch "'Technical Researcher'") {
    throw 'MDCC Master does not declare Technical Researcher.'
}

$parseErrors = $null
foreach ($script in @('scripts/setup-agent-reach.ps1', 'scripts/agent-reach-doctor.ps1')) {
    [System.Management.Automation.Language.Parser]::ParseFile(
        (Join-Path $workspaceRoot $script),
        [ref]$null,
        [ref]$parseErrors
    ) | Out-Null
}
if ($parseErrors.Count -gt 0) { throw ($parseErrors | Out-String) }

Write-Host 'Agent Reach integration validation passed.'
Write-Host "Version: $($config.upstream.version)"
Write-Host "SHA-256: $actualHash"
