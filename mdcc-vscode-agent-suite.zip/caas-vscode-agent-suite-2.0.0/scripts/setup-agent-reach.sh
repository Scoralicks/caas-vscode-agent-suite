#!/usr/bin/env bash
set -euo pipefail

mode="${1:-safe}"
channels="${2:-}"
case "$mode" in
  safe|dry-run|full) ;;
  *) echo "Usage: $0 [safe|dry-run|full] [comma-separated-channels]" >&2; exit 2 ;;
esac

workspace_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source_zip="$workspace_root/vendor/agent-reach/Agent-Reach-main.zip"
runtime_dir="$workspace_root/.tools/agent-reach"
export PIP_CACHE_DIR="$runtime_dir/.pip-cache"
expected_sha="757a2c098ab23cc646e545512938e670ae6aaadb50a0d0060d3f51d14cee7161"

test -f "$source_zip" || { echo "Agent Reach source was not found: $source_zip" >&2; exit 1; }
actual_sha="$(python3 -c 'import hashlib,sys; print(hashlib.sha256(open(sys.argv[1], "rb").read()).hexdigest())' "$source_zip")"
test "$actual_sha" = "$expected_sha" || { echo "Agent Reach checksum mismatch." >&2; exit 1; }
python3 -c 'import sys; assert sys.version_info >= (3, 10), "Python 3.10 or newer is required"'

test -x "$runtime_dir/bin/python" || python3 -m venv "$runtime_dir"
"$runtime_dir/bin/python" -m pip install --disable-pip-version-check --upgrade "$source_zip"
export PATH="$runtime_dir/bin:$PATH"

args=(install --env=auto)
test "$mode" = safe && args+=(--safe)
test "$mode" = dry-run && args+=(--dry-run)
test -n "$channels" && args+=("--channels=$channels")
"$runtime_dir/bin/agent-reach" "${args[@]}"

echo "Agent Reach 1.5.0 is ready in $runtime_dir"
