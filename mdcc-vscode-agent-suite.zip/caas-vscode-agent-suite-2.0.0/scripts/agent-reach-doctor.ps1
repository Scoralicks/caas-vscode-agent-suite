$ErrorActionPreference = 'Stop'
$workspaceRoot = Split-Path -Parent $PSScriptRoot
$agentReach = Join-Path $workspaceRoot '.tools\agent-reach\Scripts\agent-reach.exe'
if (-not (Test-Path -LiteralPath $agentReach)) {
    throw 'Agent Reach is not installed. Run the task "Research: Install Agent Reach (safe)" first.'
}
$env:PATH = "$(Split-Path -Parent $agentReach);$env:PATH"
& $agentReach doctor --json
exit $LASTEXITCODE
