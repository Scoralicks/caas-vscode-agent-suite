#!/usr/bin/env bash
set -euo pipefail
workspace_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
agent_reach="$workspace_root/.tools/agent-reach/bin/agent-reach"
test -x "$agent_reach" || { echo 'Agent Reach is not installed. Run scripts/setup-agent-reach.sh safe first.' >&2; exit 1; }
export PATH="$(dirname "$agent_reach"):$PATH"
exec "$agent_reach" doctor --json
