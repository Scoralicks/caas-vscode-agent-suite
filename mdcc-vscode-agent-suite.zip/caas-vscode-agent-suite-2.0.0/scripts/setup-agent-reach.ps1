[CmdletBinding()]
param(
    [ValidateSet('Safe', 'DryRun', 'Full')]
    [string]$Mode = 'Safe',
    [string[]]$Channels = @()
)

$ErrorActionPreference = 'Stop'
$workspaceRoot = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $workspaceRoot 'config\agent-reach.json'
$config = Get-Content -Raw -LiteralPath $configPath | ConvertFrom-Json
$sourceZip = Join-Path $workspaceRoot $config.upstream.source
$runtimeDir = Join-Path $workspaceRoot $config.runtime.directory
$pipCacheDir = Join-Path $runtimeDir '.pip-cache'

if (-not (Test-Path -LiteralPath $sourceZip -PathType Leaf)) {
    throw "Agent Reach source was not found: $sourceZip"
}

$actualHash = (Get-FileHash -LiteralPath $sourceZip -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actualHash -ne $config.upstream.sha256) {
    throw "Agent Reach checksum mismatch. Expected $($config.upstream.sha256), got $actualHash."
}

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    throw 'Python 3.10 or newer is required.'
}

$pythonVersion = & $python.Source -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
$versionParts = $pythonVersion.Split('.')
if ([int]$versionParts[0] -lt 3 -or ([int]$versionParts[0] -eq 3 -and [int]$versionParts[1] -lt 10)) {
    throw "Python 3.10 or newer is required; found $pythonVersion."
}

$venvPython = Join-Path $runtimeDir 'Scripts\python.exe'
if (-not (Test-Path -LiteralPath $venvPython)) {
    & $python.Source -m venv $runtimeDir
}

$env:PIP_CACHE_DIR = $pipCacheDir
& $venvPython -m pip install --disable-pip-version-check --upgrade $sourceZip
if ($LASTEXITCODE -ne 0) { throw 'Agent Reach package installation failed.' }

$agentReach = Join-Path $runtimeDir 'Scripts\agent-reach.exe'
if (-not (Test-Path -LiteralPath $agentReach)) {
    throw "Agent Reach executable was not created: $agentReach"
}
$env:PATH = "$(Split-Path -Parent $agentReach);$env:PATH"

$arguments = @('install', '--env=auto')
switch ($Mode) {
    'Safe' { $arguments += '--safe' }
    'DryRun' { $arguments += '--dry-run' }
    'Full' { }
}
if ($Channels.Count -gt 0) {
    $arguments += "--channels=$($Channels -join ',')"
}

& $agentReach @arguments
if ($LASTEXITCODE -ne 0) { throw "Agent Reach setup failed with exit code $LASTEXITCODE." }

Write-Host "Agent Reach $($config.upstream.version) is ready in $runtimeDir"
Write-Host 'Run the VS Code task "Research: Agent Reach doctor" to inspect channel availability.'
