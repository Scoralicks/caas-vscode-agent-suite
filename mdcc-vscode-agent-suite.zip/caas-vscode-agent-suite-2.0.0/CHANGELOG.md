# Changelog

## 2.0.0 - 2026-08-01

- adiciona o agente `Technical Researcher`;
- integra a skill do Agent Reach ao workspace;
- inclui Agent Reach 1.5.0 vendorizado com licença e checksum;
- adiciona instalação isolada nos modos seguro, simulação e completo;
- adiciona diagnóstico de canais em JSON;
- separa fontes oficiais de sinais comunitários;
- adiciona tarefas multiplataforma do VS Code e cenários de aceitação.
